-- EXEMPLOS INDEX E SEQUENCES

--index

create index title_description
on film (title, description, length);

drop index index_film;

--sequence
create sequence seq_teste
as smallint
start with 1
increment by 1;

alter sequence seq_teste minvalue 1 maxvalue 10 cycle;

select nextval('seq_teste');

drop sequence seq_teste;